Machine Learning in Finance
Aarhus University

This archive holds the exercise and case notebooks for every session, and the
price data they use.

    session_01/  session_02/  session_03/     the notebooks, and a copy of the
                                              data each one needs
    data/                                     all of the price files together

Getting started
---------------
1. Unzip this somewhere sensible.
2. In VS Code, use File > Open Folder and pick the unzipped folder. Open the
   folder, not a single file: that is what makes data/prices.csv resolve.
3. Open a notebook, choose your Python when asked, and run the first cell.

You need Python, VS Code and a few packages. The setup guide walks through it:

    https://theill95.github.io/mlfin-2026/setup.html

If you would rather not install anything, every notebook also opens in Google
Colab straight from the course page, and loads its data by itself:

    https://theill95.github.io/mlfin-2026/

The lectures are not in this archive. They are interactive pages whose code
cells only run when served over the web, so they are best used online, from the
course page above.

Questions: jobo@econ.au.dk

(c) 2026 Jonas Theill Bojstrup. Course materials for enrolled students.
