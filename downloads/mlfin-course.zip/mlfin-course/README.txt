Machine Learning in Finance
Aarhus University

This archive holds the exercise and case notebooks of every session, the data
they use, and the list of package versions the course was checked with.

    session_01/ ... session_13/   each session's notebooks and a copy of the data
                                  it uses (Sessions 7, 10 and 13 have data only)
    data/                         every data file of the course, together
    requirements.txt              the package versions the course was checked with

Getting started
---------------
1. Unzip this somewhere sensible.
2. In VS Code, use File > Open Folder and pick the unzipped folder. Open the
   folder, not a single file: that is what makes data/prices.csv resolve.
3. Open a notebook, choose your Python when asked, and run the first cell.

You need Python 3.14 (3.12 and 3.13 work too; 3.15 not yet), VS Code, and the
course's packages. Install the packages once, from any notebook cell:

    %pip install -r https://theill95.github.io/mlfin-2026/requirements.txt

The setup guide walks through all of it:

    https://theill95.github.io/mlfin-2026/setup.html

If you would rather not install anything, every notebook also opens in Google
Colab straight from the course page, and loads its data by itself:

    https://theill95.github.io/mlfin-2026/

The lectures are not in this archive. They are interactive pages whose code
cells only run when served over the web, so they are best used online, from the
course page above.

Questions: jobo@econ.au.dk

(c) 2026 Jonas Theill Bojstrup
