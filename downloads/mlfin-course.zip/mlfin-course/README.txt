Machine Learning in Finance
Aarhus University

This archive holds the exercise and case notebooks of every session, the data
they use, and the list of package versions the course was checked with.

    session_01/ ... session_13/   each session's notebooks and a copy of the data
                                  it uses (Sessions 7, 10 and 13 have data only)
    data/                         every data file of the course, together
    requirements.txt              the package versions the course was checked with
    setup_check.ipynb             run it once before the exam, with Wi-Fi off

Exam readiness (updated 15 October 2026)
---------------------------------------
Everyone: run this updated setup_check.ipynb in local VS Code using your exam
Python kernel. Turn off internet, restart the kernel, then Run All. Read the
final verdict and confirm the plot appears. Replace older copies of the check.
A stopped run or kernel crash is not a pass. Colab does not test your laptop.

Mac users: check XGBoost and LightGBM. If all checks pass, no additional install
is needed. ONLY if an error says libomp.dylib is not loaded/not found, reconnect,
install Homebrew from https://brew.sh if needed, follow its Next steps, then
run `brew install libomp` in macOS Terminal (not a Python cell).
For missing packages use the %pip command below in your exam kernel.
For an architecture mismatch or another error, use the notebook's instructions
and keep the full error and environment details if you need help.
After fixing anything, restart the kernel and repeat Run All offline.

https://theill95.github.io/mlfin-2026/exam_info.html#readiness

Getting started
---------------
1. Unzip this somewhere sensible.
2. In VS Code, use File > Open Folder and pick the unzipped folder. Open the
   folder, not a single file: that is what makes data/prices.csv resolve.
3. Open a notebook, choose your Python when asked, and run the first cell.

You need Python 3.14 (3.12 and 3.13 work too; 3.15 not yet), VS Code, and the
course's packages. Install the packages once, from any notebook cell:

    %pip install -r https://theill95.github.io/mlfin-2026/requirements.txt

The setup guide walks through all of it:

    https://theill95.github.io/mlfin-2026/setup.html

For online practice only (not the offline exam), every notebook also opens in Google
Colab straight from the course page, and loads its data by itself:

    https://theill95.github.io/mlfin-2026/

The interactive lectures are not in this archive: their code cells only run
when served over the web, so they are best used online, from the course page
above. For reading offline, every lecture is also a PDF with the result of every
code cell, on the Exam info page:

    https://theill95.github.io/mlfin-2026/exam_info.html

Questions: jobo@econ.au.dk

(c) 2026 Jonas Theill Bojstrup. The notebooks are free to reuse and adapt
under CC BY 4.0, with credit to the course; the data files keep their
sources' terms. Both are explained here:

    https://theill95.github.io/mlfin-2026/resources.html#licence
